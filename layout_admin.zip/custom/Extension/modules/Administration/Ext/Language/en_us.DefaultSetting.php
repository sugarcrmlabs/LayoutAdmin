<?php
$mod_strings['LBL_LINK_NAME'] = 'Layout Settings';
$mod_strings['LBL_LINK_DESCRIPTION'] = 'Determine column layout for modules';
$mod_strings['LBL_SECTION_HEADER'] = 'Layout Settings';
$mod_strings['LBL_DEFAULT_SETTING_TITLE'] = 'Layout Settings';
$mod_strings['LBL_SECTION_DESCRIPTION'] = 'Set the column numbers to be shown';
